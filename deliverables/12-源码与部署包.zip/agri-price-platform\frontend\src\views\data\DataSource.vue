<template>
  <div class="page">
    <PageHeader title="数据源管理" subtitle="维护价格数据接入来源，查看连接状态与同步情况">
      <template #actions>
        <el-button :icon="Refresh" @click="loadSources">刷新</el-button>
        <el-button v-if="canManage" type="primary" :icon="Plus" @click="openCreate">新增数据源</el-button>
      </template>
    </PageHeader>

    <div class="kpi-grid">
      <KpiCard label="数据源数量" :value="sources.length" unit="个" icon="Connection" tone="blue" hint="已登记的数据接入来源" />
      <KpiCard label="已连接" :value="connectedCount" unit="个" icon="CircleCheck" tone="green" hint="状态正常的接入来源" />
      <KpiCard label="累计记录数" :value="fmtInt(recordTotal)" unit="条" icon="DataLine" tone="purple" hint="各数据源同步入库记录合计" />
      <KpiCard label="最近同步" :value="lastSyncText" icon="Clock" tone="orange" hint="最近一次同步完成时间" />
    </div>

    <section class="page-card">
      <div class="card-title">
        <span>数据源列表</span>
        <span class="muted">支持 API 对接、文件接入与数据库直连</span>
      </div>
      <el-table v-loading="loading" :data="sources" empty-text="暂无数据源，点击右上角新增">
        <el-table-column prop="name" label="名称" min-width="180" show-overflow-tooltip>
          <template #default="scope">
            <div class="source-name">{{ scope.row.name }}</div>
            <div v-if="scope.row.description" class="source-desc">{{ scope.row.description }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="类型" width="100" align="center">
          <template #default="scope">
            <el-tag size="small" effect="plain">{{ scope.row.type || '—' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="protocol" label="协议" width="110" align="center">
          <template #default="scope">{{ scope.row.protocol || '—' }}</template>
        </el-table-column>
        <el-table-column prop="owner" label="负责人" width="110">
          <template #default="scope">{{ scope.row.owner || '—' }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="scope">
            <el-tag :type="statusTag(scope.row.status)" size="small" effect="light">{{ scope.row.status || '—' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="最近同步" width="160">
          <template #default="scope">{{ fmtDateTime(scope.row.last_sync_at) }}</template>
        </el-table-column>
        <el-table-column label="记录数" width="110" align="right">
          <template #default="scope">{{ fmtInt(scope.row.record_count) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="190" fixed="right">
          <template #default="scope">
            <el-button
              link
              type="primary"
              :loading="syncingId === scope.row.id"
              :disabled="!canManage"
              @click="syncSource(scope.row)"
            >
              同步
            </el-button>
            <el-button link type="primary" :disabled="!canManage" @click="openEdit(scope.row)">编辑</el-button>
            <el-button link type="danger" :disabled="!canManage" @click="removeSource(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </section>

    <el-dialog v-model="dialogVisible" :title="editingId ? '编辑数据源' : '新增数据源'" width="540px" :close-on-click-modal="false">
      <el-form label-width="88px">
        <el-form-item label="名称" required>
          <el-input v-model="form.name" maxlength="60" placeholder="如：农产品批发市场公开接口" />
        </el-form-item>
        <el-form-item label="类型" required>
          <el-select v-model="form.type" filterable allow-create default-first-option style="width: 100%">
            <el-option v-for="item in typeOptions" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="协议" required>
          <el-select v-model="form.protocol" filterable allow-create default-first-option style="width: 100%">
            <el-option v-for="item in protocolOptions" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="负责人">
          <el-input v-model="form.owner" maxlength="30" placeholder="数据对接负责人" />
        </el-form-item>
        <el-form-item label="说明">
          <el-input v-model="form.description" type="textarea" :rows="3" maxlength="200" show-word-limit placeholder="数据范围、更新频率等说明" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="saveSource">{{ editingId ? '保存' : '创建' }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import api, { ApiError } from '@/api/client'
import PageHeader from '@/components/PageHeader.vue'
import KpiCard from '@/components/KpiCard.vue'
import { useAuthStore } from '@/stores/auth'
import { fmtDateTime, fmtInt } from '@/utils/format'

interface SourceRow {
  id: number
  name: string
  type: string
  protocol: string
  owner?: string
  status: string
  last_sync_at?: string
  record_count?: number
  description?: string
}

interface SyncResult {
  ok: boolean
  synced: number
  status: string
  last_sync_at: string
}

const auth = useAuthStore()
const canManage = computed(() => auth.hasPerm('data:source'))

const typeOptions = ['API', '文件', '数据库', '手工填报']
const protocolOptions = ['HTTP', 'HTTPS', 'FTP', 'SFTP', 'JDBC', '本地文件']

const sources = ref<SourceRow[]>([])
const loading = ref(false)
const syncingId = ref<number | null>(null)

const dialogVisible = ref(false)
const saving = ref(false)
const editingId = ref<number | null>(null)
const form = reactive({ name: '', type: 'API', protocol: 'HTTPS', owner: '', description: '' })

const connectedCount = computed(
  () => sources.value.filter((item) => ['已连接', '正常', '在线', '启用'].includes(item.status)).length,
)

const recordTotal = computed(() => sources.value.reduce((sum, item) => sum + (Number(item.record_count) || 0), 0))

const lastSyncText = computed(() => {
  const times = sources.value
    .map((item) => item.last_sync_at)
    .filter((value): value is string => Boolean(value))
    .sort()
  return times.length ? fmtDateTime(times[times.length - 1]) : '—'
})

function statusTag(status?: string): 'success' | 'warning' | 'danger' | 'info' {
  if (!status) return 'info'
  if (['已连接', '正常', '在线', '启用'].includes(status)) return 'success'
  if (['同步中', '待连接', '维护中'].includes(status)) return 'warning'
  if (['异常', '离线', '失败', '停用'].includes(status)) return 'danger'
  return 'info'
}

function isNotFound(error: unknown): boolean {
  if (error instanceof ApiError) return error.code === 'E4040'
  const status = (error as { response?: { status?: number } })?.response?.status
  return status === 404
}

async function loadSources() {
  loading.value = true
  try {
    sources.value = (await api.get<SourceRow[]>('/sources')) || []
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editingId.value = null
  form.name = ''
  form.type = 'API'
  form.protocol = 'HTTPS'
  form.owner = ''
  form.description = ''
  dialogVisible.value = true
}

function openEdit(row: SourceRow) {
  editingId.value = row.id
  form.name = row.name || ''
  form.type = row.type || 'API'
  form.protocol = row.protocol || 'HTTPS'
  form.owner = row.owner || ''
  form.description = row.description || ''
  dialogVisible.value = true
}

async function saveSource() {
  if (!form.name.trim()) {
    ElMessage.warning('请输入数据源名称')
    return
  }
  if (!form.type) {
    ElMessage.warning('请选择数据源类型')
    return
  }
  if (!form.protocol) {
    ElMessage.warning('请选择接入协议')
    return
  }
  const payload = {
    name: form.name.trim(),
    type: form.type,
    protocol: form.protocol,
    owner: form.owner.trim(),
    description: form.description.trim(),
  }
  saving.value = true
  try {
    if (editingId.value) {
      await api.put(`/sources/${editingId.value}`, payload)
      ElMessage.success('数据源已更新')
    } else {
      await api.post('/sources', payload)
      ElMessage.success('数据源已创建')
    }
    dialogVisible.value = false
    await loadSources()
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    saving.value = false
  }
}

async function syncSource(row: SourceRow) {
  syncingId.value = row.id
  try {
    const result = await api.post<SyncResult>(`/sources/${row.id}/sync`)
    ElMessage.success(`同步完成，新增 ${fmtInt(result.synced)} 条记录`)
    await loadSources()
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    syncingId.value = null
  }
}

async function removeSource(row: SourceRow) {
  try {
    await ElMessageBox.confirm(
      `确认删除数据源「${row.name}」？删除后该来源的历史导入记录仍会保留。`,
      '删除确认',
      { type: 'warning', confirmButtonText: '删除', cancelButtonText: '取消' },
    )
  } catch {
    return
  }
  try {
    await api.delete(`/sources/${row.id}`)
    ElMessage.success('数据源已删除')
    await loadSources()
  } catch (error) {
    if (isNotFound(error)) {
      ElMessage.warning('当前版本暂不支持删除数据源，已保留该记录')
    } else {
      ElMessage.warning('数据服务暂不可用')
    }
  }
}

onMounted(() => {
  loadSources()
})
</script>

<style scoped>
.source-name {
  font-weight: 500;
  color: #1c2a3a;
}

.source-desc {
  margin-top: 2px;
  overflow: hidden;
  font-size: 12px;
  color: #8b9aae;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
