<template>
  <div class="page">
    <PageHeader title="数据导入" subtitle="通过 CSV 模板批量导入价格数据，系统逐行校验并回显失败原因">
      <template #actions>
        <el-button :icon="Download" @click="downloadTemplate">下载模板</el-button>
        <el-button :icon="Refresh" @click="refreshAll">刷新</el-button>
      </template>
    </PageHeader>

    <div class="import-grid">
      <section class="page-card">
        <div class="card-title"><span>上传文件</span></div>
        <el-upload
          ref="uploadRef"
          v-model:file-list="fileList"
          drag
          accept=".csv"
          :auto-upload="false"
          :limit="1"
          :on-change="onFileChange"
          :on-remove="onFileRemove"
          :on-exceed="onExceed"
        >
          <el-icon class="upload-icon"><UploadFilled /></el-icon>
          <div class="el-upload__text">将 CSV 文件拖到此处，或<em>点击选择</em></div>
          <template #tip>
            <div class="el-upload__tip">仅支持 .csv 文件，单次选择一个文件；可先下载模板按列填写。</div>
          </template>
        </el-upload>

        <el-form label-width="82px" class="source-form">
          <el-form-item label="数据源">
            <el-select v-model="sourceId" placeholder="选择数据源" filterable style="width: 100%">
              <el-option v-for="item in sources" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
          </el-form-item>
        </el-form>

        <div class="import-actions">
          <el-button v-if="canImport" type="primary" :loading="importing" :icon="Upload" @click="startImport">
            开始导入
          </el-button>
          <el-button v-else disabled>开始导入</el-button>
          <span class="muted import-hint">
            {{ canImport ? '导入前请确认文件编码为 UTF-8' : '当前账号无数据导入权限' }}
          </span>
        </div>
      </section>

      <section class="page-card">
        <div class="card-title">
          <span>导入结果</span>
          <el-tag v-if="result" :type="resultTagType(result)" size="small" effect="light">
            {{ result.rows_error ? '存在失败行' : '校验通过' }}
          </el-tag>
        </div>
        <el-empty v-if="!result" description="选择文件并点击“开始导入”，结果将在此展示" />
        <template v-else>
          <div class="result-stats">
            <div class="result-stat">
              <span>总行数</span>
              <strong>{{ fmtInt(result.rows_total) }}</strong>
            </div>
            <div class="result-stat ok">
              <span>成功</span>
              <strong>{{ fmtInt(result.rows_ok) }}</strong>
            </div>
            <div class="result-stat error">
              <span>失败</span>
              <strong>{{ fmtInt(result.rows_error) }}</strong>
            </div>
            <div class="result-stat">
              <span>跳过</span>
              <strong>{{ fmtInt(result.rows_skipped) }}</strong>
            </div>
          </div>

          <template v-if="result.errors && result.errors.length">
            <div class="error-title">
              <span>失败明细</span>
              <span v-if="result.truncated" class="muted">仅展示前 {{ result.errors.length }} 条</span>
            </div>
            <el-table :data="result.errors" size="small" max-height="240" class="error-table">
              <el-table-column prop="row" label="行号" width="86" />
              <el-table-column prop="message" label="错误原因" min-width="220" show-overflow-tooltip />
            </el-table>
          </template>
          <el-empty v-else description="本次导入没有校验失败行" :image-size="64" />
        </template>
      </section>
    </div>

    <section class="page-card">
      <div class="card-title">
        <span>导入历史</span>
        <span class="muted">共 {{ fmtInt(historyTotal) }} 条</span>
      </div>
      <el-table v-loading="historyLoading" :data="historyRows" empty-text="暂无导入记录">
        <el-table-column prop="filename" label="文件名" min-width="200" show-overflow-tooltip>
          <template #default="scope">{{ scope.row.filename || '—' }}</template>
        </el-table-column>
        <el-table-column prop="source" label="数据源" width="160" show-overflow-tooltip>
          <template #default="scope">{{ scope.row.source || '—' }}</template>
        </el-table-column>
        <el-table-column label="总行数" width="90" align="right">
          <template #default="scope">{{ fmtInt(scope.row.rows_total) }}</template>
        </el-table-column>
        <el-table-column label="成功" width="90" align="right">
          <template #default="scope"><span class="text-down">{{ fmtInt(scope.row.rows_ok) }}</span></template>
        </el-table-column>
        <el-table-column label="失败" width="90" align="right">
          <template #default="scope">
            <span :class="scope.row.rows_error ? 'text-up' : 'muted'">{{ fmtInt(scope.row.rows_error) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="scope">
            <el-tag :type="statusTag(scope.row.status)" size="small" effect="light">{{ scope.row.status || '—' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="created_by" label="操作人" width="110">
          <template #default="scope">{{ scope.row.created_by || '—' }}</template>
        </el-table-column>
        <el-table-column label="导入时间" width="160">
          <template #default="scope">{{ fmtDateTime(scope.row.created_at) }}</template>
        </el-table-column>
      </el-table>
      <div class="pagination-bar">
        <el-pagination
          v-model:current-page="historyPage"
          layout="total, prev, pager, next"
          :total="historyTotal"
          :page-size="historyPageSize"
          @current-change="loadHistory"
        />
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import type { UploadFile, UploadInstance, UploadUserFile } from 'element-plus'
import { Download, Refresh, Upload } from '@element-plus/icons-vue'
import api, { type Paged } from '@/api/client'
import PageHeader from '@/components/PageHeader.vue'
import { useAuthStore } from '@/stores/auth'
import { fmtDateTime, fmtInt } from '@/utils/format'

interface SourceOption {
  id: number
  name: string
  type?: string
  status?: string
  record_count?: number
}

interface ImportError {
  row: number
  message: string
}

interface ImportResult {
  task_id: number
  rows_total: number
  rows_ok: number
  rows_error: number
  rows_skipped?: number
  status?: string
  errors?: ImportError[]
  truncated?: boolean
}

interface ImportTask {
  id: number
  source?: string
  filename?: string
  rows_total: number
  rows_ok: number
  rows_error: number
  status: string
  created_by?: string
  created_at: string
}

const auth = useAuthStore()
const canImport = computed(() => auth.hasPerm('data:import'))

const sources = ref<SourceOption[]>([])
const sourceId = ref<number | undefined>(undefined)
const uploadRef = ref<UploadInstance>()
const fileList = ref<UploadUserFile[]>([])
const pickedFile = ref<File | null>(null)
const importing = ref(false)
const result = ref<ImportResult | null>(null)

const historyRows = ref<ImportTask[]>([])
const historyTotal = ref(0)
const historyPage = ref(1)
const historyPageSize = 10
const historyLoading = ref(false)

function statusTag(status?: string): 'success' | 'warning' | 'danger' | 'info' {
  if (!status) return 'info'
  if (['成功', '已完成', '完成'].includes(status)) return 'success'
  if (['部分成功', '处理中', '导入中'].includes(status)) return 'warning'
  if (['失败', '异常', '错误'].includes(status)) return 'danger'
  return 'info'
}

function resultTagType(row: ImportResult): 'success' | 'warning' | 'danger' {
  if (row.rows_error > 0) return 'warning'
  return 'success'
}

function onFileChange(file: UploadFile) {
  if (file.raw) pickedFile.value = file.raw
}

function onFileRemove() {
  pickedFile.value = null
}

function onExceed() {
  ElMessage.warning('一次仅可选择一个文件，请先移除已选文件')
}

async function loadSources() {
  try {
    sources.value = (await api.get<SourceOption[]>('/sources')) || []
    if (sourceId.value === undefined && sources.value.length) sourceId.value = sources.value[0].id
  } catch {
    ElMessage.warning('数据服务暂不可用')
  }
}

async function loadHistory(targetPage = historyPage.value) {
  historyPage.value = targetPage
  historyLoading.value = true
  try {
    const data = await api.get<Paged<ImportTask>>('/data/import-tasks', {
      page: historyPage.value,
      page_size: historyPageSize,
    })
    historyRows.value = data.list || []
    historyTotal.value = data.total || 0
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    historyLoading.value = false
  }
}

function refreshAll() {
  loadSources()
  loadHistory(historyPage.value)
}

async function startImport() {
  if (!pickedFile.value) {
    ElMessage.warning('请选择要导入的 CSV 文件')
    return
  }
  if (!sourceId.value) {
    ElMessage.warning('请选择数据源')
    return
  }
  importing.value = true
  try {
    const form = new FormData()
    form.append('file', pickedFile.value)
    form.append('source_id', String(sourceId.value))
    const data = await api.upload<ImportResult>('/data/import', form)
    result.value = data
    ElMessage.success(`导入完成：成功 ${fmtInt(data.rows_ok)} 行`)
    uploadRef.value?.clearFiles()
    fileList.value = []
    pickedFile.value = null
    await Promise.all([loadHistory(1), loadSources()])
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    importing.value = false
  }
}

async function downloadTemplate() {
  try {
    await api.download('/quality/template', {}, '价格导入模板.csv')
  } catch {
    ElMessage.warning('数据服务暂不可用')
  }
}

onMounted(() => {
  loadSources()
  loadHistory(1)
})
</script>

<style scoped>
.import-grid {
  display: grid;
  grid-template-columns: 420px minmax(0, 1fr);
  gap: 16px;
  align-items: start;
}

.upload-icon {
  margin-bottom: 6px;
  font-size: 44px;
  color: #9db4d8;
}

.source-form {
  margin-top: 18px;
}

.import-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  padding-left: 82px;
}

.import-hint {
  font-size: 12px;
}

.result-stats {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 14px;
}

.result-stat {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 10px 12px;
  background: #f7f9fd;
  border-radius: 8px;
}

.result-stat span {
  font-size: 12px;
  color: #7b8ba1;
}

.result-stat strong {
  font-size: 20px;
  color: #16233a;
  font-variant-numeric: tabular-nums;
}

.result-stat.ok strong {
  color: #1c9c6b;
}

.result-stat.error strong {
  color: #d64545;
}

.error-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 4px 0 8px;
  font-size: 13px;
  font-weight: 600;
  color: #40536b;
}

.error-table {
  border: 1px solid #eef2f8;
  border-radius: 6px;
}

@media (max-width: 1280px) {
  .import-grid {
    grid-template-columns: 1fr;
  }
}
</style>
