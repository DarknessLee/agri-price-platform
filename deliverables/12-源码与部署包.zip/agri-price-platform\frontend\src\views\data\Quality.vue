<template>
  <div class="page">
    <PageHeader title="数据质量" subtitle="校验价格数据的完整率、重复率、缺失与异常，并完成问题记录处置">
      <template #actions>
        <el-button :icon="Refresh" @click="refreshAll">刷新</el-button>
        <el-button :icon="Download" @click="downloadTemplate">下载模板</el-button>
      </template>
    </PageHeader>

    <div class="kpi-grid">
      <KpiCard
        label="数据完整率"
        :value="summary ? fmtPct(summary.completeness, 2, false) : '—'"
        icon="CircleCheck"
        tone="green"
        hint="必填字段完整比例"
      />
      <KpiCard
        label="重复率"
        :value="summary ? fmtPct(summary.duplicate_rate, 2, false) : '—'"
        icon="CopyDocument"
        tone="orange"
        hint="重复记录占比"
      />
      <KpiCard
        label="异常记录"
        :value="summary ? fmtInt(summary.outlier_count) : '—'"
        unit="条"
        icon="Warning"
        tone="red"
        hint="价格异常波动记录"
      />
      <KpiCard
        label="总记录数"
        :value="summary ? fmtInt(summary.total_records) : '—'"
        unit="条"
        icon="DataLine"
        tone="blue"
        hint="价格事实表记录总量"
      />
      <KpiCard
        label="缺失记录"
        :value="summary ? fmtInt(summary.missing_count) : '—'"
        unit="条"
        icon="DocumentDelete"
        tone="purple"
        hint="缺失估算或缺失字段记录"
      />
    </div>

    <section class="page-card">
      <div class="card-title">
        <span>品种质量对比</span>
        <span class="muted">{{ summary?.updated_at ? `统计时间：${fmtDateTime(summary.updated_at)}` : '' }}</span>
      </div>
      <BaseChart :option="chartOption" :height="300" :loading="summaryLoading" :empty="!byVariety.length" empty-text="暂无品种质量数据" />
    </section>

    <section class="page-card">
      <div class="card-title">
        <span>异常明细</span>
        <span class="muted">共 {{ fmtInt(issueTotal) }} 条</span>
      </div>
      <div class="toolbar">
        <el-select v-model="issueType" placeholder="问题类型" clearable style="width: 160px" @change="loadIssues(1)">
          <el-option label="全部类型" value="" />
          <el-option v-for="item in issueTypes" :key="item" :label="item" :value="item" />
        </el-select>
        <el-select v-model="issueStatus" placeholder="处置状态" clearable style="width: 140px" @change="loadIssues(1)">
          <el-option label="全部状态" value="" />
          <el-option v-for="item in issueStatuses" :key="item" :label="item" :value="item" />
        </el-select>
        <div class="grow" />
      </div>

      <el-table v-loading="issuesLoading" :data="issues" empty-text="暂无异常记录">
        <el-table-column label="日期" width="120">
          <template #default="scope">{{ fmtDate(scope.row.date) }}</template>
        </el-table-column>
        <el-table-column prop="variety" label="品种" width="100" />
        <el-table-column prop="region" label="地区" width="120" />
        <el-table-column label="价格" width="110" align="right">
          <template #default="scope"><span class="mono">{{ fmtNum(scope.row.price) }}</span></template>
        </el-table-column>
        <el-table-column label="问题类型" width="130" align="center">
          <template #default="scope">
            <el-tag :type="issueTagType(scope.row.issue_type)" size="small" effect="light">{{ scope.row.issue_type }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="detail" label="详情" min-width="240" show-overflow-tooltip>
          <template #default="scope">{{ scope.row.detail || '—' }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="scope">
            <el-tag :type="issueStatusTag(scope.row.status)" size="small" effect="light">{{ scope.row.status || '—' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="90" fixed="right">
          <template #default="scope">
            <el-button
              v-if="scope.row.status === '待处理'"
              link
              type="primary"
              :disabled="!canHandle"
              @click="openResolve(scope.row)"
            >
              处置
            </el-button>
            <span v-else class="muted">—</span>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-bar">
        <el-pagination
          v-model:current-page="issuePage"
          layout="total, prev, pager, next"
          :total="issueTotal"
          :page-size="issuePageSize"
          @current-change="loadIssues"
        />
      </div>
    </section>

    <el-dialog v-model="resolveVisible" title="问题处置" width="480px" :close-on-click-modal="false">
      <div v-if="currentIssue" class="issue-brief">
        <div><span class="muted">问题：</span>{{ currentIssue.issue_type }}</div>
        <div><span class="muted">记录：</span>{{ fmtDate(currentIssue.date) }} · {{ currentIssue.variety }} · {{ currentIssue.region }}</div>
        <div><span class="muted">详情：</span>{{ currentIssue.detail || '—' }}</div>
      </div>
      <el-radio-group v-model="resolveAction" class="resolve-actions">
        <el-radio value="fix">修正数据（标记为已处理）</el-radio>
        <el-radio value="exclude">排除记录（标记为已排除）</el-radio>
      </el-radio-group>
      <template #footer>
        <el-button @click="resolveVisible = false">取消</el-button>
        <el-button type="primary" :loading="resolving" @click="submitResolve">确认处置</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import type { EChartsOption } from 'echarts'
import { Download, Refresh } from '@element-plus/icons-vue'
import api, { type Paged } from '@/api/client'
import PageHeader from '@/components/PageHeader.vue'
import KpiCard from '@/components/KpiCard.vue'
import BaseChart from '@/components/BaseChart.vue'
import { useAuthStore } from '@/stores/auth'
import { fmtDate, fmtDateTime, fmtInt, fmtNum, fmtPct } from '@/utils/format'

interface QualitySummary {
  completeness?: number
  duplicate_rate?: number
  outlier_count?: number
  total_records?: number
  missing_count?: number
  by_variety?: Array<{ variety: string; completeness: number; outliers: number }>
  updated_at?: string
}

interface IssueRow {
  id: number
  date: string
  variety: string
  region: string
  price: number
  issue_type: string
  detail?: string
  status: string
}

const issueTypes = ['价格异常波动', '数据缺失估算', '重复记录', '格式错误']
const issueStatuses = ['待处理', '已处理', '已排除']

const auth = useAuthStore()
const canHandle = computed(() => auth.hasPerm('data:import'))

const summary = ref<QualitySummary | null>(null)
const summaryLoading = ref(false)

const issues = ref<IssueRow[]>([])
const issueTotal = ref(0)
const issuePage = ref(1)
const issuePageSize = 10
const issuesLoading = ref(false)
const issueType = ref('')
const issueStatus = ref('')

const resolveVisible = ref(false)
const resolving = ref(false)
const currentIssue = ref<IssueRow | null>(null)
const resolveAction = ref<'fix' | 'exclude'>('fix')

const byVariety = computed(() => summary.value?.by_variety || [])

const chartOption = computed<EChartsOption>(() => {
  const rows = byVariety.value
  return {
    tooltip: { trigger: 'axis' },
    legend: { data: ['完整率', '异常数'], top: 0, right: 0, itemWidth: 14 },
    grid: { left: 10, right: 18, top: 42, bottom: 8, containLabel: true },
    xAxis: {
      type: 'category',
      data: rows.map((item) => item.variety),
      axisLabel: { color: '#7b8ba1', interval: 0, rotate: rows.length > 8 ? 22 : 0 },
      axisLine: { lineStyle: { color: '#dfe6f0' } },
    },
    yAxis: [
      {
        type: 'value',
        name: '完整率(%)',
        min: 0,
        max: 100,
        splitLine: { lineStyle: { color: '#eef2f8' } },
        axisLabel: { color: '#7b8ba1' },
      },
      {
        type: 'value',
        name: '异常数',
        splitLine: { show: false },
        axisLabel: { color: '#7b8ba1' },
      },
    ],
    series: [
      {
        name: '完整率',
        type: 'bar',
        barWidth: 22,
        data: rows.map((item) => item.completeness),
        itemStyle: { color: '#1f5fd6', borderRadius: [4, 4, 0, 0] },
      },
      {
        name: '异常数',
        type: 'bar',
        yAxisIndex: 1,
        barWidth: 16,
        data: rows.map((item) => item.outliers),
        itemStyle: { color: '#e8a33d', borderRadius: [4, 4, 0, 0] },
      },
    ],
  }
})

function issueTagType(type?: string): 'danger' | 'warning' | 'info' | 'success' {
  if (type === '价格异常波动') return 'danger'
  if (type === '数据缺失估算') return 'warning'
  if (type === '重复记录') return 'info'
  if (type === '格式错误') return 'danger'
  return 'info'
}

function issueStatusTag(status?: string): 'danger' | 'warning' | 'success' | 'info' {
  if (status === '待处理') return 'danger'
  if (status === '已处理') return 'success'
  if (status === '已排除') return 'info'
  return 'info'
}

async function loadSummary() {
  summaryLoading.value = true
  try {
    summary.value = await api.get<QualitySummary>('/quality/summary')
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    summaryLoading.value = false
  }
}

async function loadIssues(targetPage = issuePage.value) {
  issuePage.value = targetPage
  issuesLoading.value = true
  try {
    const params: Record<string, unknown> = { page: issuePage.value, page_size: issuePageSize }
    if (issueType.value) params.type = issueType.value
    if (issueStatus.value) params.status = issueStatus.value
    const data = await api.get<Paged<IssueRow>>('/quality/issues', params)
    issues.value = data.list || []
    issueTotal.value = data.total || 0
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    issuesLoading.value = false
  }
}

function refreshAll() {
  loadSummary()
  loadIssues(issuePage.value)
}

function openResolve(row: IssueRow) {
  currentIssue.value = row
  resolveAction.value = 'fix'
  resolveVisible.value = true
}

async function submitResolve() {
  const issue = currentIssue.value
  if (!issue) return
  resolving.value = true
  try {
    await api.post(`/quality/issues/${issue.id}/resolve`, { action: resolveAction.value })
    ElMessage.success('处置完成')
    resolveVisible.value = false
    await Promise.all([loadSummary(), loadIssues(issuePage.value)])
  } catch {
    ElMessage.warning('数据服务暂不可用')
  } finally {
    resolving.value = false
  }
}

async function downloadTemplate() {
  try {
    await api.download('/quality/template', {}, '价格导入模板.csv')
  } catch {
    ElMessage.warning('数据服务暂不可用')
  }
}

onMounted(() => {
  loadSummary()
  loadIssues(1)
})
</script>

<style scoped>
.issue-brief {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 18px;
  padding: 12px 14px;
  font-size: 13px;
  line-height: 1.6;
  color: #2a3a4d;
  background: #f7f9fd;
  border-radius: 8px;
}

.resolve-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  align-items: flex-start;
}
</style>
